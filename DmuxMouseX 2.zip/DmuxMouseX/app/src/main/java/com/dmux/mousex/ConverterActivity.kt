package com.dmux.mousex

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.util.UUID

@Suppress("DEPRECATION")
class ConverterActivity : Activity() {
    private val OUT = UUID.fromString("0000fc01-0000-1000-8000-00805f9b34fb")
    private val IN = UUID.fromString("0000fc02-0000-1000-8000-00805f9b34fb")
    private val HID = UUID.fromString("00001812-0000-1000-8000-00805f9b34fb")
    private val CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val BG = 0xFF0E1014.toInt(); private val CARD = 0xFF171A21.toInt()
    private val ACCENT = 0xFF7C6CF0.toInt(); private val TXT = 0xFFECEEF3.toInt()
    private lateinit var list: LinearLayout
    private lateinit var logv: TextView
    private lateinit var hex: EditText
    private var gatt: BluetoothGatt? = null
    private var outChar: BluetoothGattCharacteristic? = null
    private val seen = HashSet<String>()
    private val h = Handler(Looper.getMainLooper())
    private val sb = StringBuilder()
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r.dp().toFloat() }

    private fun log(s: String) = runOnUiThread { sb.append(s).append('\n'); logv.text = sb.toString() }
    private fun hexOf(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

    private fun btn(p: LinearLayout, t: String, primary: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(TXT); background = rr(if (primary) ACCENT else 0xFF262A33.toInt(), 12)
        setOnClickListener { f() }; p.addView(this, LinearLayout.LayoutParams(-1, 46.dp()).apply { topMargin = 6.dp() })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val sv = ScrollView(this).apply { setBackgroundColor(BG) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 40.dp(), 16.dp(), 24.dp()) }
        sv.addView(box); setContentView(sv)
        box.addView(TextView(this).apply { text = "ทดสอบตัวแปลง"; textSize = 26f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD })
        box.addView(TextView(this).apply {
            text = "ปิดแอป KuGamer ก่อน แล้วกดสแกน ดาวติดข้างชื่อ = มีบริการ HID"; textSize = 13f; setTextColor(0xFF8A90A0.toInt()); setPadding(0, 4.dp(), 0, 8.dp())
        })
        btn(box, "สแกนอุปกรณ์ (10 วินาที)", true) { scan() }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; box.addView(list)
        logv = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(TXT); background = rr(CARD, 12)
            setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp()); setTextIsSelectable(true); minHeight = 160.dp()
        }
        box.addView(logv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12.dp() })
        btn(box, "คัดลอกบันทึก (ส่งให้ผมดู)") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", sb.toString()))
            Toast.makeText(this, "คัดลอกแล้ว", Toast.LENGTH_SHORT).show()
        }
        hex = EditText(this).apply {
            hint = "ส่ง hex (ขั้นสูง) เช่น FF 01 00"; setTextColor(TXT); setHintTextColor(0xFF8A90A0.toInt()); textSize = 13f
            background = rr(CARD, 12); setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
        }
        box.addView(hex, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12.dp() })
        btn(box, "ส่งไปที่ตัวแปลง") { send() }
        btn(box, "ตัดการเชื่อมต่อ") { gatt?.close(); gatt = null; log("ตัดการเชื่อมต่อแล้ว") }
    }

    private fun need(): Boolean {
        val ps = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                 else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (ps.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) return false
        requestPermissions(ps, 1); return true
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) scan() else log("ไม่ได้รับอนุญาตบลูทูธ")
    }

    private val scb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            val d = r.device; val name = d.name ?: return
            if (!seen.add(d.address)) return
            val hid = r.scanRecord?.serviceUuids?.any { it.uuid == HID } == true
            runOnUiThread { btn(list, (if (hid) "★ " else "") + name + "  " + d.address) { connect(d) } }
        }
    }

    private fun scan() {
        if (need()) return
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { log("เปิดบลูทูธก่อน"); return }
        seen.clear(); list.removeAllViews()
        val sc = ad.bluetoothLeScanner; sc.startScan(scb); log("กำลังสแกน...")
        h.postDelayed({ try { sc.stopScan(scb) } catch (_: Exception) {}; log("สแกนเสร็จ") }, 10000)
    }

    private fun connect(d: BluetoothDevice) {
        gatt?.close(); log("เชื่อมต่อ " + d.name + " ...")
        gatt = d.connectGatt(this, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, st: Int, ns: Int) {
                log("สถานะ: " + ns + " (code " + st + ")")
                if (ns == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            }
            override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
                for (s in g.services) {
                    log("บริการ " + s.uuid.toString().substring(0, 8))
                    for (c in s.characteristics) log("   ลักษณะ " + c.uuid.toString().substring(0, 8) + " props=" + c.properties)
                }
                val i = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == IN }
                outChar = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == OUT }
                if (i == null) { log("ไม่พบช่อง FC02 (อาจไม่ใช่ตัวแปลง หรือเครื่องไม่เปิดช่องนี้)"); return }
                g.setCharacteristicNotification(i, true)
                i.getDescriptor(CCC)?.let { it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(it) }
                log("สมัครรับข้อมูล FC02 แล้ว ลองกดปุ่มบนคีย์บอร์ด/ขยับเมาส์ที่ต่อกับตัวแปลง")
            }
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                log("← " + hexOf(c.value))
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    private fun send() {
        val c = outChar ?: run { log("ยังไม่ได้เชื่อมต่อ"); return }
        try {
            val b = hex.text.toString().trim().split(Regex("\\s+")).map { it.toInt(16).toByte() }.toByteArray()
            c.value = b; gatt?.writeCharacteristic(c); log("→ " + hexOf(b))
        } catch (_: Exception) { log("รูปแบบ hex ไม่ถูกต้อง") }
    }

    override fun onDestroy() { gatt?.close(); super.onDestroy() }
}
