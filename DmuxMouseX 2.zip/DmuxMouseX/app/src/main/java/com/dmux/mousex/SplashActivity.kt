package com.dmux.mousex

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SplashActivity : Activity() {
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bg = 0xFF0E1014.toInt()
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(bg); setPadding(32.dp(), 32.dp(), 32.dp(), 32.dp())
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_logo); alpha = 0f }
        root.addView(logo, LinearLayout.LayoutParams(128.dp(), 128.dp()))
        logo.animate().alpha(1f).setDuration(700).start()

        root.addView(TextView(this).apply {
            text = "Dmux Mouse X"; textSize = 32f; setTextColor(0xFFECEEF3.toInt())
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 24.dp(), 0, 6.dp())
        })
        root.addView(TextView(this).apply {
            text = "เมาส์และคีย์บอร์ดสำหรับเกมมือถือ"; textSize = 15f
            setTextColor(0xFF8A90A0.toInt()); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "ปรับความไว  •  สร้างปุ่มเอง  •  จอย WASD  •  มาโคร"; textSize = 12f
            setTextColor(0xFF5E6472.toInt()); gravity = Gravity.CENTER; setPadding(0, 14.dp(), 0, 40.dp())
        })
        root.addView(Button(this).apply {
            text = "เริ่มใช้งาน"; isAllCaps = false; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply { setColor(0xFF7C6CF0.toInt()); cornerRadius = 14.dp().toFloat() }
            setOnClickListener { startActivity(Intent(this@SplashActivity, MainActivity::class.java)); finish() }
        }, LinearLayout.LayoutParams(220.dp(), 52.dp()))
        setContentView(root)
    }
}
