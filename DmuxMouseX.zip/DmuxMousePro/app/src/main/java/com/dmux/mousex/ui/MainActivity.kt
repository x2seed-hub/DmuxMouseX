package com.dmux.mousex.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.widget.*
import com.dmux.mousex.R
import com.dmux.mousex.data.Converter
import com.dmux.mousex.data.KeyNames
import com.dmux.mousex.data.Prefs
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

/** หน้าตั้งค่าหลัก แบ่งเป็น 3 แท็บ: หน้าหลัก / ปุ่มและมาโคร / ตั้งค่า */
class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private var macroEdit: EditText? = null
    private var tab = 0

    override fun onCreate(b: Bundle?) { super.onCreate(b); p = Prefs(this) }
    override fun onResume() { super.onResume(); build() }
    override fun onPause() { saveMacro(); super.onPause() }

    private fun Int.dp() = Ui.dp(this@MainActivity, this)
    private fun saveMacro() { macroEdit?.let { p.macro = it.text.toString() } }
    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()
    private fun tv(parent: LinearLayout, t: String, size: Float = 14f, color: Int = Ui.SUB, bold: Boolean = false) =
        Ui.text(this, parent, t, size, color, bold)
    private fun card(title: String, sub: String? = null) = Ui.card(this, box, title, sub)
    private fun btn(parent: LinearLayout, t: String, primary: Boolean = false, click: () -> Unit) =
        Ui.button(this, parent, t, primary, click)

    private fun serviceOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(packageName) == true

    // ---------- โครงหน้า ----------
    private fun build() {
        window.statusBarColor = Ui.BG; window.navigationBarColor = Ui.BG
        macroEdit = null
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 40.dp(), 16.dp(), 32.dp()) }
        sv.addView(box); setContentView(sv)
        header(); tabBar()
        when (tab) { 0 -> homeTab(); 1 -> keysTab(); else -> settingsTab() }
    }

    private fun header() {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4.dp(), 0, 4.dp(), 16.dp()) }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(60.dp(), 60.dp()))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14.dp(), 0, 0, 0) }
        tv(ht, getString(R.string.app_name), 26f, Ui.TXT, true); tv(ht, getString(R.string.tagline), 13f, Ui.SUB)
        head.addView(ht); box.addView(head)
    }

    private fun tabBar() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 14.dp()) }
        val names = intArrayOf(R.string.tab_home, R.string.tab_keys, R.string.tab_settings)
        for (i in names.indices) {
            val on = i == tab
            row.addView(Button(this).apply {
                text = getString(names[i]); isAllCaps = false; textSize = 13f
                typeface = Typeface.DEFAULT_BOLD; setTextColor(if (on) Ui.BG else Ui.TXT)
                background = Ui.round(this@MainActivity, if (on) Ui.SKY else Ui.PANEL, 12)
                minWidth = 0; minimumWidth = 0
                setOnClickListener { if (tab != i) { saveMacro(); tab = i; build() } }
            }, LinearLayout.LayoutParams(0, 44.dp(), 1f).apply { if (i > 0) leftMargin = 8.dp() })
        }
        box.addView(row)
    }

    // ---------- แท็บ 1: หน้าหลัก ----------
    private fun homeTab() {
        val on = serviceOn()
        val st = card(getString(R.string.status_title))
        tv(st, getString(if (on) R.string.status_ready else R.string.status_off), 14f, if (on) Ui.OK else Ui.WARN)
        btn(st, getString(if (on) R.string.acc_settings else R.string.acc_open), !on) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val bt = card(getString(R.string.bt_card_title), getString(R.string.bt_card_sub))
        tv(bt, if (p.lastDevAddr.isEmpty()) getString(R.string.bt_never) else getString(R.string.bt_last, p.lastDevName), 13f, Ui.SUB)
        btn(bt, getString(R.string.bt_manage), true) { startActivity(Intent(this, BluetoothActivity::class.java)) }

        val cd = card(getString(R.string.conv_title), getString(R.string.conv_sub))
        val here = Converter.present(p)
        tv(cd, getString(if (here) R.string.conv_found else R.string.conv_missing), 14f, if (here) Ui.OK else Ui.WARN)
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and (InputDevice.SOURCE_KEYBOARD or InputDevice.SOURCE_MOUSE)) == 0) continue
            val chosen = Converter.tokens(p).any { d.name.contains(it, true) }
            btn(cd, (if (chosen) "✓ " else "") + d.name, chosen) { toggleDev(d.name) }
        }
        btn(cd, getString(R.string.refresh)) { build() }

        val ap = card(getString(R.string.games_title), getString(R.string.games_sub))
        for (i in 0..2) {
            val pk = p.app(i)
            val row = LinearLayout(this)
            ap.addView(row, LinearLayout.LayoutParams(-1, -2))
            if (pk.isEmpty()) {
                rowBtn(row, getString(R.string.add_game), false, 1f) { pickApp(i) }
            } else {
                val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pk, 0)).toString() } catch (_: Exception) { pk }
                rowBtn(row, "▶  $name", true, 1f) { launchGame(pk) }
                rowBtn(row, "✎", false, 0f) { pickApp(i) }
                rowBtn(row, "✕", false, 0f) { p.setApp(i, ""); build() }
            }
        }
    }

    // ---------- แท็บ 2: ปุ่มและมาโคร ----------
    private fun keysTab() {
        val n = p.apps().fold(0) { acc, a -> acc + (try { JSONArray(p.buttons(a)).length() } catch (_: Exception) { 0 }) }
        val bt = card(getString(R.string.onscreen_title), getString(R.string.onscreen_sub, n))
        tv(bt, getString(R.string.onscreen_howto), 13f, Ui.SUB)

        val mc = card(getString(R.string.macro_title), getString(R.string.macro_sub))
        btn(mc, getString(R.string.macro_key, KeyNames.full(this, p.macroKey))) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setMessage(R.string.press_key)
                .setOnKeyListener { d, k, e ->
                    if (e.action == KeyEvent.ACTION_DOWN && k != KeyEvent.KEYCODE_BACK) { p.macroKey = k; d.dismiss(); build(); true } else false
                }.show()
        }
        macroEdit = EditText(this).apply {
            setText(p.macro); minLines = 5; gravity = Gravity.TOP; typeface = Typeface.MONOSPACE
            setTextColor(Ui.TXT); setHintTextColor(Ui.SUB); textSize = 13f
            background = Ui.round(this@MainActivity, Ui.BG, 12); setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
            hint = getString(R.string.macro_hint)
            mc.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8.dp() })
        }
        btn(mc, getString(R.string.macro_save), true) { saveMacro(); toast(R.string.saved) }
    }

    // ---------- แท็บ 3: ตั้งค่า ----------
    private fun settingsTab() {
        val sn = card(getString(R.string.sens_title))
        seek(sn, getString(R.string.axis_x), "%", 10, 400, (p.sensX * 100).toInt()) { p.sensX = it / 100f }
        seek(sn, getString(R.string.axis_y), "%", 10, 400, (p.sensY * 100).toInt()) { p.sensY = it / 100f }

        val cu = card(getString(R.string.cursor_title))
        seek(cu, getString(R.string.size), " " + getString(R.string.unit_size), 16, 128, p.cursorDp) { p.cursorDp = it }
        btn(cu, getString(R.string.pick_image)) { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        btn(cu, getString(R.string.default_image)) { File(filesDir, "cursor.png").delete(); toast(R.string.reset_done) }

        val tp = card(getString(R.string.play_title))
        tv(tp, getString(R.string.play_help), 13f, Ui.SUB)
    }

    // ---------- ตัวช่วย ----------
    private fun seek(parent: LinearLayout, label: String, unit: String, min: Int, max: Int, init: Int, set: (Int) -> Unit) {
        val t = tv(parent, "$label: $init$unit", 14f, Ui.TXT)
        parent.addView(SeekBar(this).apply {
            this.max = max - min; progress = init - min
            progressTintList = ColorStateList.valueOf(Ui.SKY); thumbTintList = ColorStateList.valueOf(Ui.AMBER)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(v + min); t.text = "$label: ${v + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun rowBtn(row: LinearLayout, t: String, primary: Boolean, w: Float, click: () -> Unit) =
        Button(this).apply {
            text = t; isAllCaps = false; setTextColor(if (primary) Ui.BG else Ui.TXT); textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = Ui.round(this@MainActivity, if (primary) Ui.SKY else Ui.FIELD, 12)
            setOnClickListener { click() }
            row.addView(this, LinearLayout.LayoutParams(if (w > 0f) 0 else 52.dp(), 48.dp(), w).apply {
                topMargin = 8.dp(); leftMargin = if (row.childCount > 0) 8.dp() else 0
            })
        }

    private fun launchGame(pk: String) {
        if (!serviceOn()) { toast(R.string.toast_enable_acc); return }
        if (!Converter.present(p)) { toast(R.string.toast_no_conv); return }
        val i = packageManager.getLaunchIntentForPackage(pk)
        if (i == null) toast(R.string.toast_cant_launch) else startActivity(i)
    }

    private fun toggleDev(name: String) {
        val cur = Converter.tokens(p).toMutableList()
        val hit = cur.filter { name.contains(it, true) }
        if (hit.isNotEmpty()) cur.removeAll(hit) else cur.add(name)
        p.devs = cur.joinToString(",")
        build()
    }

    private fun pickApp(slot: Int) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.sortedBy { it.second }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setItems(apps.map { it.second }.toTypedArray()) { _, i -> p.setApp(slot, apps[i].first); build() }.show()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc != 1 || res != RESULT_OK) return
        try {
            val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u))
            FileOutputStream(File(filesDir, "cursor.png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            toast(R.string.image_changed)
        } catch (_: Exception) { toast(R.string.image_failed) }
    }
}
