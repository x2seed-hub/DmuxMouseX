package com.dmux.mousex.ui

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.*
import com.dmux.mousex.R
import com.dmux.mousex.ble.BleLink
import com.dmux.mousex.data.Prefs
import java.util.UUID

/** หน้าเชื่อมต่อบลูทูธ: สแกน เลือกเครื่อง ดูสถานะ และส่ง/รับข้อมูลดิบ (ตั้งค่า UUID ได้เอง) */
@Suppress("DEPRECATION")
class BluetoothActivity : Activity(), BleLink.Listener {
    private lateinit var p: Prefs
    private lateinit var link: BleLink
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var logv: TextView
    private lateinit var hex: EditText
    private val sb = StringBuilder()
    private fun Int.dp() = Ui.dp(this@BluetoothActivity, this)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        link = BleLink(this, UUID.fromString("0000fc01-0000-1000-8000-00805f9b34fb"), UUID.fromString("0000fc02-0000-1000-8000-00805f9b34fb"))
        link.listener = this; link.autoReconnect = p.autoReconnect
        window.statusBarColor = Ui.BG; window.navigationBarColor = Ui.BG
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 40.dp(), 16.dp(), 28.dp()) }
        sv.addView(box); setContentView(sv)

        Ui.text(this, box, getString(R.string.bt_title), 26f, Ui.TXT, true)
        Ui.text(this, box, getString(R.string.bt_sub), 13f, Ui.SUB).setPadding(0, 2.dp(), 0, 10.dp())

        val st = Ui.card(this, box, getString(R.string.bt_state_title))
        status = Ui.text(this, st, getString(R.string.bt_state_idle), 14f, Ui.WARN, true)
        Ui.button(this, st, getString(R.string.bt_scan), true) { startScan() }
        if (p.lastDevAddr.isNotEmpty())
            Ui.button(this, st, getString(R.string.bt_connect_last, p.lastDevName)) { if (!needPerm()) link.connectSaved(p.lastDevAddr) }
        Ui.button(this, st, getString(R.string.bt_disconnect)) { link.disconnect() }
        val auto = CheckBox(this).apply {
            text = getString(R.string.bt_auto); setTextColor(Ui.TXT); isChecked = p.autoReconnect
            setOnCheckedChangeListener { _, v -> p.autoReconnect = v; link.autoReconnect = v }
        }
        st.addView(auto)

        val dv = Ui.card(this, box, getString(R.string.bt_found_title))
        list = dv

        val tool = Ui.card(this, box, getString(R.string.bt_raw_title), getString(R.string.bt_raw_sub))
        hex = EditText(this).apply {
            hint = "01 02 03"; setTextColor(Ui.TXT); setHintTextColor(Ui.SUB); textSize = 13f
            typeface = Typeface.MONOSPACE; background = Ui.round(this@BluetoothActivity, Ui.FIELD, 10)
            setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
        }
        tool.addView(hex, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6.dp() })
        Ui.button(this, tool, getString(R.string.bt_send)) { send() }

        val lg = Ui.card(this, box, getString(R.string.bt_log_title))
        logv = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Ui.TXT)
            background = Ui.round(this@BluetoothActivity, Ui.BG, 10); setTextIsSelectable(true)
            setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp()); minHeight = 140.dp()
        }
        lg.addView(logv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6.dp() })
        Ui.button(this, lg, getString(R.string.bt_copy_log)) {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", sb.toString()))
            Toast.makeText(this, R.string.bt_copied, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- สิทธิ์และการสแกน ----------
    private fun needPerm(): Boolean {
        val ps = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                 else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (ps.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) return false
        requestPermissions(ps, 1); return true
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
        else onLog(getString(R.string.bt_perm_denied))
    }

    private fun startScan() {
        if (needPerm()) return
        if (!link.enabled()) { onLog(getString(R.string.bt_turn_on)); return }
        list.removeAllViews()
        Ui.text(this, list, getString(R.string.bt_found_title), 17f, Ui.TXT, true)
        link.scan()
    }

    private fun send() {
        try {
            val b = hex.text.toString().trim().split(Regex("\\s+")).map { it.toInt(16).toByte() }.toByteArray()
            if (link.send(b)) onLog("→ " + hexOf(b)) else onLog(getString(R.string.bt_not_connected))
        } catch (_: Exception) { onLog(getString(R.string.bt_bad_hex)) }
    }

    private fun hexOf(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

    // ---------- BleLink.Listener ----------
    override fun onState(s: BleLink.State, detail: String) {
        status.text = "● $detail"
        status.setTextColor(when (s) { BleLink.State.CONNECTED -> Ui.OK; BleLink.State.IDLE -> Ui.WARN; else -> Ui.SKY })
        onLog(detail)
    }

    override fun onFound(d: BluetoothDevice, rssi: Int, hid: Boolean) {
        Ui.button(this, list, (if (hid) "★ " else "") + getString(R.string.bt_device_row, d.name ?: d.address, rssi)) { link.connect(d) }
    }

    override fun onData(bytes: ByteArray) { onLog("← " + hexOf(bytes)) }

    override fun onLog(line: String) { sb.append(line).append('\n'); logv.text = sb.toString() }

    override fun onDestroy() { link.close(); super.onDestroy() }
}
