package com.dmux.mousex.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import com.dmux.mousex.R

class SplashActivity : Activity() {
    private fun Int.dp() = Ui.dp(this@SplashActivity, this)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG; window.navigationBarColor = Ui.BG
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Ui.BG); setPadding(32.dp(), 32.dp(), 32.dp(), 32.dp())
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_logo); alpha = 0f; translationY = 16f }
        root.addView(logo, LinearLayout.LayoutParams(132.dp(), 132.dp()))
        logo.animate().alpha(1f).translationY(0f).setDuration(600).start()

        Ui.text(this, root, getString(R.string.app_name), 30f, Ui.TXT, true).apply {
            gravity = Gravity.CENTER; setPadding(0, 24.dp(), 0, 6.dp())
        }
        Ui.text(this, root, getString(R.string.splash_tagline), 15f, Ui.SUB).gravity = Gravity.CENTER
        Ui.text(this, root, getString(R.string.splash_features), 12f, Ui.SUB).apply {
            gravity = Gravity.CENTER; setPadding(0, 12.dp(), 0, 40.dp())
        }
        root.addView(Button(this).apply {
            text = getString(R.string.start); isAllCaps = false; textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(Ui.BG)
            background = Ui.round(this@SplashActivity, Ui.AMBER, 14)
            setOnClickListener { startActivity(Intent(this@SplashActivity, MainActivity::class.java)); finish() }
        }, LinearLayout.LayoutParams(220.dp(), 52.dp()))
        setContentView(root)
    }
}
