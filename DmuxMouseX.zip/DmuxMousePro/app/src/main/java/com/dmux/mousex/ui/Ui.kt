package com.dmux.mousex.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** ธีมและตัวช่วยสร้าง UI ที่ใช้ร่วมกันทุกหน้า */
object Ui {
    const val BG = 0xFF14202B.toInt()
    const val PANEL = 0xFF1D2D3B.toInt()
    const val FIELD = 0xFF263A4B.toInt()
    const val SKY = 0xFF5BC0EB.toInt()
    const val AMBER = 0xFFFFB454.toInt()
    const val TXT = 0xFFEAF2F8.toInt()
    const val SUB = 0xFF8FA6B8.toInt()
    const val OK = 0xFF58D68D.toInt()
    const val WARN = 0xFFFFB454.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(c, r).toFloat() }

    fun text(c: Context, parent: LinearLayout?, t: String, size: Float = 14f, color: Int = SUB, bold: Boolean = false) =
        TextView(c).apply {
            text = t; textSize = size; setTextColor(color)
            setPadding(0, dp(c, 3), 0, dp(c, 3))
            if (bold) typeface = Typeface.DEFAULT_BOLD
            parent?.addView(this)
        }

    /** primary = ปุ่มหลัก (ฟ้า) ปุ่มอื่นเป็นพื้นเข้ม */
    fun button(c: Context, parent: LinearLayout, t: String, primary: Boolean = false, click: () -> Unit) =
        Button(c).apply {
            text = t; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) BG else TXT)
            typeface = Typeface.DEFAULT_BOLD
            background = round(c, if (primary) SKY else FIELD, 12)
            setOnClickListener { click() }
            parent.addView(this, LinearLayout.LayoutParams(-1, dp(c, 48)).apply { topMargin = dp(c, 8) })
        }

    /** การ์ดหัวข้อ: แถบสีด้านซ้ายบอกว่าเป็นกลุ่มเดียวกัน */
    fun card(c: Context, parent: LinearLayout, title: String, sub: String? = null): LinearLayout {
        val outer = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; background = round(c, PANEL, 14) }
        outer.addView(android.view.View(c).apply { background = round(c, SKY, 3) },
            LinearLayout.LayoutParams(dp(c, 4), -1).apply { setMargins(dp(c, 10), dp(c, 14), 0, dp(c, 14)) })
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 14), dp(c, 12), dp(c, 16), dp(c, 14))
        }
        outer.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(outer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 12) })
        text(c, col, title, 17f, TXT, true)
        sub?.let { text(c, col, it, 13f, SUB) }
        return col
    }
}
