package com.dmux.mousex.data

import android.content.Context
import android.content.Intent

/** แคชรายชื่อแอปในเครื่อง โหลดครั้งเดียวตอนเปิดแอป เพื่อให้หน้าหลักและหน้าเลือกเกมเปิดทันที */
object AppCache {
    @Volatile var launchers: List<Pair<String, String>> = emptyList(); private set
    @Volatile private var labels: Map<String, String> = emptyMap()

    /** report ส่งความคืบหน้าจริง 0..1 ตามจำนวนแอปที่อ่านชื่อเสร็จ */
    fun load(ctx: Context, report: (Float) -> Unit = {}) {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val seen = HashSet<String>(); val out = ArrayList<Pair<String, String>>()
        list.forEachIndexed { i, ri ->
            val pk = ri.activityInfo.packageName
            if (seen.add(pk)) out.add(pk to ri.loadLabel(pm).toString())
            report((i + 1f) / list.size)
        }
        launchers = out.sortedBy { it.second }
        labels = out.toMap()
    }

    fun label(ctx: Context, pk: String): String = labels[pk] ?: try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pk, 0)).toString()
    } catch (_: Exception) { pk }
}
