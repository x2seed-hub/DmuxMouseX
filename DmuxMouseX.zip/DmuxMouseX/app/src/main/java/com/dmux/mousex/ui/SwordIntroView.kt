package com.dmux.mousex.ui

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.dmux.mousex.R
import kotlin.math.min
import kotlin.random.Random

/**
 * หน้าโหลดแบบชักดาบ: ใบดาบเผยออกมาตามความคืบหน้าจริง (setProgress)
 * ครบ 100% -> วาบ -> ฟัน -> หน้าจอขาดเป็นสองซีกแยกออก เผยหน้าแอปที่อยู่ข้างใต้
 */
class SwordIntroView(ctx: Context, private val onFinished: () -> Unit) : View(ctx) {
    private enum class Phase { LOAD, FLASH, SLASH, SPLIT, DONE }
    private class Spark(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float)

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private var phase = Phase.LOAD
    private var target = 0f
    private var shown = 0f
    private var label = ""
    private var phaseStart = 0L
    private var lastFrame = 0L
    private var looping = false
    private var snap: Bitmap? = null
    private val sparks = ArrayList<Spark>()

    private var gx = 0f; private var gy = 0f; private var bladeMax = 0f
    private var ax = 0f; private var bx = 0f
    private val half1 = Path(); private val half2 = Path()
    private val swingEnd = 70f
    private val splitMs = 700L

    private val bgPaint = Paint()
    private val steel = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val scab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = dp(1.5f)
        pathEffect = DashPathEffect(floatArrayOf(dp(6f), dp(6f)), 0f)
    }
    private val tmp = Path()

    /** ความคืบหน้าจริง 0..1 (รับเฉพาะค่าที่เพิ่มขึ้น) */
    fun setProgress(f: Float, l: String) { target = maxOf(target, f.coerceIn(0f, 1f)); label = l }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        gx = dp(96f); gy = h * 0.46f; bladeMax = w - gx - dp(24f)
        ax = w * 0.78f; bx = w * 0.22f
        half1.reset(); half1.moveTo(0f, 0f); half1.lineTo(ax, 0f); half1.lineTo(bx, h.toFloat()); half1.lineTo(0f, h.toFloat()); half1.close()
        half2.reset(); half2.moveTo(ax, 0f); half2.lineTo(w.toFloat(), 0f); half2.lineTo(w.toFloat(), h.toFloat()); half2.lineTo(bx, h.toFloat()); half2.close()
        bgPaint.shader = RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.75f, Ui.PANEL, Ui.BG, Shader.TileMode.CLAMP)
        steel.shader = LinearGradient(0f, gy - dp(8f), 0f, gy + dp(8f),
            intArrayOf(0xFFF2F7FB.toInt(), 0xFF9FB4C4.toInt(), 0xFFE3ECF2.toInt()), null, Shader.TileMode.CLAMP)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (phase != Phase.DONE && !looping) { looping = true; lastFrame = SystemClock.uptimeMillis(); postOnAnimation(tick) }
    }

    override fun onDetachedFromWindow() { looping = false; super.onDetachedFromWindow() }
    override fun onTouchEvent(e: MotionEvent) = true

    private val tick = object : Runnable {
        override fun run() {
            if (!looping) return
            val now = SystemClock.uptimeMillis()
            val dt = min(0.05f, (now - lastFrame) / 1000f); lastFrame = now
            step(now, dt); invalidate()
            if (phase != Phase.DONE) postOnAnimation(this) else looping = false
        }
    }

    private fun ease(t: Float) = t * t * (3f - 2f * t)

    private fun step(now: Long, dt: Float) {
        when (phase) {
            Phase.LOAD -> {
                val before = shown
                shown += (target - shown) * 0.16f
                if (target - shown < 0.003f) shown = target
                if (shown > before) emit(((shown - before) * 80f).toInt().coerceIn(1, 4))
                sparkStep(dt)
                if (shown >= 1f) { phase = Phase.FLASH; phaseStart = now }
            }
            Phase.FLASH -> { sparkStep(dt); if (now - phaseStart >= 220) { phase = Phase.SLASH; phaseStart = now } }
            Phase.SLASH -> if (now - phaseStart >= 240) {
                makeSnapshot(); performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                phase = Phase.SPLIT; phaseStart = now
            }
            Phase.SPLIT -> if (now - phaseStart >= splitMs) {
                phase = Phase.DONE; snap?.recycle(); snap = null; onFinished()
            }
            Phase.DONE -> {}
        }
    }

    private fun emit(n: Int) {
        val tx = gx + bladeMax * shown
        repeat(n) { sparks.add(Spark(tx, gy, Random.nextFloat() * dp(70f) - dp(10f), -Random.nextFloat() * dp(90f), 1f)) }
    }

    private fun sparkStep(dt: Float) {
        val it = sparks.iterator()
        while (it.hasNext()) {
            val s = it.next(); s.x += s.vx * dt; s.y += s.vy * dt; s.vy += dp(160f) * dt; s.life -= dt / 0.55f
            if (s.life <= 0f) it.remove()
        }
    }

    private fun makeSnapshot() {
        if (width == 0 || height == 0) return
        val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(b); drawScene(c, swingEnd); drawSlash(c, 1f, 1f); snap = b
    }

    // ---------- วาด ----------
    private fun bladePath(len: Float, hw: Float): Path {
        val tip = min(len * 0.6f, dp(34f))
        tmp.reset(); tmp.moveTo(gx, gy - hw); tmp.lineTo(gx + len - tip, gy - hw)
        tmp.lineTo(gx + len, gy - hw * 0.3f); tmp.lineTo(gx + len - tip * 0.8f, gy + hw); tmp.lineTo(gx, gy + hw); tmp.close()
        return tmp
    }

    private fun drawScene(c: Canvas, swing: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bgPaint)

        txt.color = Ui.TXT; txt.textSize = dp(28f)
        c.drawText(context.getString(R.string.app_name), w / 2f, gy - dp(110f), txt)

        if (phase == Phase.LOAD) c.drawPath(bladePath(bladeMax, dp(8f)), scab)

        c.save(); if (swing != 0f) c.rotate(swing, gx, gy)
        val len = bladeMax * shown
        if (len > 1f) {
            val hw = dp(8f); val tip = min(len * 0.6f, dp(34f))
            c.drawPath(bladePath(len, hw), steel)
            line.strokeWidth = dp(1.5f); line.color = 0xAAFFFFFF.toInt()
            c.drawLine(gx + dp(4f), gy - hw + dp(1.5f), gx + len - tip, gy - hw + dp(1.5f), line)
            line.color = 0x33000000
            c.drawLine(gx + dp(6f), gy, gx + len - tip, gy, line)
        }
        fill.color = 0xFF2B4A5F.toInt()
        c.drawRect(gx - dp(72f), gy - dp(7f), gx - dp(8f), gy + dp(7f), fill)
        line.strokeWidth = dp(1.5f); line.color = 0x99FFB454.toInt()
        var x = gx - dp(70f)
        while (x < gx - dp(10f)) { c.drawLine(x, gy + dp(7f), x + dp(8f), gy - dp(7f), line); x += dp(10f) }
        fill.color = Ui.AMBER
        c.drawRoundRect(gx - dp(10f), gy - dp(20f), gx + dp(2f), gy + dp(20f), dp(3f), dp(3f), fill)
        c.drawCircle(gx - dp(78f), gy, dp(8f), fill)
        c.restore()

        for (s in sparks) { fill.color = Color.argb((s.life * 255).toInt().coerceIn(0, 255), 255, 180, 84); c.drawCircle(s.x, s.y, dp(2.2f), fill) }

        txt.color = Ui.SKY; txt.textSize = dp(44f)
        c.drawText(context.getString(R.string.intro_percent, (shown * 100f).toInt().coerceIn(0, 100)), w / 2f, gy + dp(90f), txt)
        txt.color = Ui.SUB; txt.textSize = dp(13f); txt.typeface = Typeface.DEFAULT
        c.drawText(if (shown >= 1f) context.getString(R.string.ld_ready) else context.getString(R.string.intro_loading, label), w / 2f, gy + dp(118f), txt)
        txt.typeface = Typeface.DEFAULT_BOLD
    }

    private fun drawSlash(c: Canvas, s: Float, alpha: Float) {
        val ex = ax + (bx - ax) * s; val ey = height * s
        line.color = Color.argb((0x22 * alpha).toInt(), 91, 192, 235); line.strokeWidth = dp(30f); c.drawLine(ax, 0f, ex, ey, line)
        line.color = Color.argb((0x66 * alpha).toInt(), 91, 192, 235); line.strokeWidth = dp(14f); c.drawLine(ax, 0f, ex, ey, line)
        line.color = Color.argb((0xFF * alpha).toInt(), 255, 255, 255); line.strokeWidth = dp(4f); c.drawLine(ax, 0f, ex, ey, line)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        when (phase) {
            Phase.LOAD -> drawScene(c, 0f)
            Phase.FLASH -> {
                val t = ((now - phaseStart) / 220f).coerceIn(0f, 1f)
                drawScene(c, 0f)
                val tx = gx + bladeMax; val a = (1f - t)
                line.color = Color.argb((255 * a).toInt(), 255, 255, 255); line.strokeWidth = dp(2.5f)
                val r = dp(46f) * a
                c.drawLine(tx - r, gy, tx + r, gy, line); c.drawLine(tx, gy - r, tx, gy + r, line)
                fill.color = Color.argb((60 * a).toInt(), 255, 255, 255); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
            }
            Phase.SLASH -> {
                val t = ((now - phaseStart) / 240f).coerceIn(0f, 1f)
                drawScene(c, swingEnd * ease(t)); drawSlash(c, ease(t), 1f)
            }
            Phase.SPLIT -> drawSplit(c, now)
            Phase.DONE -> {}
        }
    }

    private fun drawSplit(c: Canvas, now: Long) {
        val b = snap ?: return
        val t = ((now - phaseStart) / splitMs.toFloat()).coerceIn(0f, 1f)
        val e = t * t
        drawSlash(c, 1f, 1f - t)
        val pa = Paint().apply { alpha = (255 * (1f - maxOf(0f, (t - 0.6f) / 0.4f))).toInt().coerceIn(0, 255) }
        val w = width.toFloat(); val h = height.toFloat()
        c.save(); c.translate(-e * w * 0.45f, -e * h * 0.03f); c.rotate(-e * 7f, 0f, h)
        c.clipPath(half1); c.drawBitmap(b, 0f, 0f, pa); c.restore()
        c.save(); c.translate(e * w * 0.45f, e * h * 0.03f); c.rotate(e * 7f, w, 0f)
        c.clipPath(half2); c.drawBitmap(b, 0f, 0f, pa); c.restore()
    }
}
