package com.dmux.mousex.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import com.dmux.mousex.data.Prefs
import java.io.File
import java.io.FileOutputStream

/** พื้นหลังแอปที่ผู้ใช้เปลี่ยนเองได้ เก็บเป็นไฟล์ bg.jpg ในแอป (ย่อให้พอดีหน้าจอ) */
object AppBackground {
    private var bmp: Bitmap? = null
    private var loaded = false
    private var dimView: View? = null

    private fun file(c: Context) = File(c.filesDir, "bg.jpg")

    /** ถอดรหัสรูปที่บันทึกไว้ ย่อลงให้ไม่ใหญ่เกินหน้าจอ */
    fun load(c: Context) {
        val f = file(c)
        bmp = if (f.exists()) try {
            val dm = c.resources.displayMetrics
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= dm.widthPixels && o.outHeight / (s * 2) >= dm.heightPixels) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (_: Throwable) { null } else null
        loaded = true
    }

    private fun get(c: Context): Bitmap? { if (!loaded) load(c); return bmp }

    /** บันทึกรูปที่เลือก (ย่อให้ด้านยาวไม่เกิน 1600 พิกเซล) */
    fun save(c: Context, uri: Uri): Boolean = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 1600) s *= 2
        val b = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        if (b == null) false else {
            FileOutputStream(file(c)).use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            b.recycle(); load(c); true
        }
    } catch (_: Throwable) { false }

    fun clear(c: Context) { file(c).delete(); bmp = null; loaded = true }

    fun applyDim(percent: Int) { dimView?.setBackgroundColor(Color.argb(percent * 255 / 100, 0, 0, 0)) }

    /** ชั้นพื้นหลังสำหรับวางใต้เนื้อหา (ถ้ามีรูป การ์ดจะโปร่งเล็กน้อยให้เห็นพื้นหลัง) */
    fun layer(c: Context): FrameLayout {
        val f = FrameLayout(c); f.setBackgroundColor(Ui.BG)
        val b = get(c)
        dimView = null
        if (b != null) {
            f.addView(ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(b) },
                FrameLayout.LayoutParams(-1, -1))
            val dim = View(c); f.addView(dim, FrameLayout.LayoutParams(-1, -1)); dimView = dim
            applyDim(Prefs(c).bgDim)
        }
        Ui.panelAlpha = if (b != null) 0xE0 else 0xFF
        return f
    }
}
