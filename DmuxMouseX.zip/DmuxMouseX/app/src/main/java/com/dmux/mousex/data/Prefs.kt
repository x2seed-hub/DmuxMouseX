package com.dmux.mousex.data

import android.content.Context
import com.dmux.mousex.R

class Prefs(private val c: Context) {
    private val sp = c.getSharedPreferences("dmux", Context.MODE_PRIVATE)
    var sensX: Float
        get() = sp.getFloat("sx", 1f)
        set(v) { sp.edit().putFloat("sx", v).apply() }
    var sensY: Float
        get() = sp.getFloat("sy", 1f)
        set(v) { sp.edit().putFloat("sy", v).apply() }
    var cursorDp: Int
        get() = sp.getInt("cs", 32)
        set(v) { sp.edit().putInt("cs", v).apply() }
    var macroKey: Int
        get() = sp.getInt("mk", 132)
        set(v) { sp.edit().putInt("mk", v).apply() }
    var macro: String
        get() = sp.getString("macro", c.getString(R.string.macro_default))!!
        set(v) { sp.edit().putString("macro", v).apply() }
    var devs: String
        get() = sp.getString("devs", "MY1Pro")!!
        set(v) { sp.edit().putString("devs", v).apply() }
    var lastDevAddr: String
        get() = sp.getString("ld_addr", "")!!
        set(v) { sp.edit().putString("ld_addr", v).apply() }
    var lastDevName: String
        get() = sp.getString("ld_name", "")!!
        set(v) { sp.edit().putString("ld_name", v).apply() }
    var autoReconnect: Boolean
        get() = sp.getBoolean("ld_auto", true)
        set(v) { sp.edit().putBoolean("ld_auto", v).apply() }
    fun buttons(pkg: String): String = sp.getString("btns_" + pkg, "[]")!!
    fun setButtons(pkg: String, v: String) { sp.edit().putString("btns_" + pkg, v).apply() }
    companion object { const val SLOTS = 8 }
    var bgDim: Int
        get() = sp.getInt("bg_dim", 45)
        set(v) { sp.edit().putInt("bg_dim", v).apply() }
    var introOn: Boolean
        get() = sp.getBoolean("intro", true)
        set(v) { sp.edit().putBoolean("intro", v).apply() }
    fun app(i: Int): String = sp.getString("app" + i, "")!!
    fun setApp(i: Int, v: String) { sp.edit().putString("app" + i, v).apply() }
    fun apps(): List<String> = (0 until SLOTS).map { app(it) }.filter { it.isNotEmpty() }
}

/** ตรวจว่าอุปกรณ์ไหนคือ "ตัวแปลง" ตามชื่อที่ผู้ใช้ติ๊กไว้ */
object Converter {
    fun tokens(p: Prefs) = p.devs.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    fun match(d: android.view.InputDevice?, p: Prefs): Boolean {
        val n = d?.name ?: return false
        return tokens(p).any { n.contains(it, true) }
    }
    fun present(p: Prefs): Boolean =
        android.view.InputDevice.getDeviceIds().any { match(android.view.InputDevice.getDevice(it), p) }
}
