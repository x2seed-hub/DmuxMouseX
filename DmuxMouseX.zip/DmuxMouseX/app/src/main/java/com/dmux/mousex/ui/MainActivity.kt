package com.dmux.mousex.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.widget.*
import com.dmux.mousex.R
import com.dmux.mousex.data.AppCache
import com.dmux.mousex.data.Converter
import com.dmux.mousex.data.KeyNames
import com.dmux.mousex.data.Prefs
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

/** หน้าตั้งค่าหลัก แบ่งเป็น 3 แท็บ: หน้าหลัก / ปุ่มและมาโคร / ตั้งค่า */
class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private var macroEdit: EditText? = null
    private var tab = 0

    private lateinit var root: FrameLayout
    private var overlay: SwordIntroView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); p = Prefs(this)
        root = FrameLayout(this); setContentView(root)
        // เล่นหน้าโหลดชักดาบเฉพาะตอนเปิดแอปใหม่ (ไม่เล่นซ้ำตอนหมุนจอหรือกลับมาจากหน้าอื่น)
        if (b == null && p.introOn) startIntro()
    }

    private fun startIntro() {
        val v = SwordIntroView(this) { overlay?.let { root.removeView(it) }; overlay = null }
        overlay = v; root.addView(v)
        Loader(this) { f, t -> v.setProgress(f, t) }.start()
    }

    /** วางพื้นหลัง + เนื้อหา และให้หน้าโหลด (ถ้ายังอยู่) อยู่บนสุดเสมอ */
    private fun showContent(content: View) {
        root.removeAllViews(); root.addView(AppBackground.layer(this)); root.addView(content)
        overlay?.let { root.addView(it) }
    }
    override fun onResume() { super.onResume(); build() }
    override fun onPause() { saveMacro(); super.onPause() }

    private fun Int.dp() = Ui.dp(this@MainActivity, this)
    private fun saveMacro() { macroEdit?.let { p.macro = it.text.toString() } }
    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()
    private fun tv(parent: LinearLayout, t: String, size: Float = 14f, color: Int = Ui.SUB, bold: Boolean = false) =
        Ui.text(this, parent, t, size, color, bold)
    private fun card(title: String, sub: String? = null) = Ui.card(this, box, title, sub)
    private fun btn(parent: LinearLayout, t: String, primary: Boolean = false, click: () -> Unit) =
        Ui.button(this, parent, t, primary, click)

    private fun serviceOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(packageName) == true

    // ---------- โครงหน้า ----------
    private fun build() {
        window.statusBarColor = Ui.BG; window.navigationBarColor = Ui.BG
        macroEdit = null
        val sv = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 40.dp(), 16.dp(), 32.dp()) }
        sv.addView(box); showContent(sv)
        header(); tabBar()
        when (tab) { 0 -> homeTab(); 1 -> keysTab(); else -> settingsTab() }
    }

    private fun header() {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4.dp(), 0, 4.dp(), 16.dp()) }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(60.dp(), 60.dp()))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14.dp(), 0, 0, 0) }
        tv(ht, getString(R.string.app_name), 26f, Ui.TXT, true); tv(ht, getString(R.string.tagline), 13f, Ui.SUB)
        head.addView(ht); box.addView(head)
    }

    private fun tabBar() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 14.dp()) }
        val names = intArrayOf(R.string.tab_home, R.string.tab_keys, R.string.tab_settings)
        for (i in names.indices) {
            val on = i == tab
            row.addView(Button(this).apply {
                text = getString(names[i]); isAllCaps = false; textSize = 13f
                typeface = Typeface.DEFAULT_BOLD; setTextColor(if (on) Ui.BG else Ui.TXT)
                background = Ui.round(this@MainActivity, if (on) Ui.SKY else Ui.panel(), 12)
                minWidth = 0; minimumWidth = 0
                setOnClickListener { if (tab != i) { saveMacro(); tab = i; build() } }
            }, LinearLayout.LayoutParams(0, 44.dp(), 1f).apply { if (i > 0) leftMargin = 8.dp() })
        }
        box.addView(row)
    }

    // ---------- แท็บ 1: หน้าหลัก ----------
    private fun homeTab() {
        val on = serviceOn()
        val here = Converter.present(p)

        // ศูนย์รวมการเชื่อมต่อ: สถานะ + ปุ่มลัด + คำแนะนำ
        val cn = card(getString(R.string.bt_card_title), getString(R.string.bt_card_sub))
        tv(cn, getString(if (here) R.string.conn_state_ok else R.string.conn_state_no), 17f, if (here) Ui.OK else Ui.WARN, true)
        tv(cn, getString(R.string.conn_state_ble, if (p.lastDevAddr.isEmpty()) getString(R.string.bt_never) else p.lastDevName), 13f, Ui.SUB)
        btn(cn, getString(R.string.bt_manage), !here) { startActivity(Intent(this, BluetoothActivity::class.java)) }
        tv(cn, getString(R.string.conn_tip_title), 13f, Ui.TXT, true).setPadding(0, 12.dp(), 0, 2.dp())
        tv(cn, "• " + getString(R.string.conn_tip_usb), 12f, Ui.SUB)
        tv(cn, "• " + getString(R.string.conn_tip_pair), 12f, Ui.SUB)

        val st = card(getString(R.string.status_title))
        tv(st, getString(if (on) R.string.status_ready else R.string.status_off), 14f, if (on) Ui.OK else Ui.WARN)
        btn(st, getString(if (on) R.string.acc_settings else R.string.acc_open), !on) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // กริดเกม 2 คอลัมน์ x 4 แถว: แตะ = เปิดเกม, แตะค้าง = ลบ
        val ap = card(getString(R.string.games_title), getString(R.string.games_sub))
        for (r in 0 until Prefs.SLOTS / 2) {
            val row = LinearLayout(this)
            ap.addView(row, LinearLayout.LayoutParams(-1, -2))
            for (c in 0..1) gameCell(row, r * 2 + c)
        }

        val cd = card(getString(R.string.conv_title), getString(R.string.conv_sub))
        tv(cd, getString(if (here) R.string.conv_found else R.string.conv_missing), 14f, if (here) Ui.OK else Ui.WARN)
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            if ((d.sources and (InputDevice.SOURCE_KEYBOARD or InputDevice.SOURCE_MOUSE)) == 0) continue
            val chosen = Converter.tokens(p).any { d.name.contains(it, true) }
            btn(cd, (if (chosen) "✓ " else "") + d.name, chosen) { toggleDev(d.name) }
        }
        btn(cd, getString(R.string.refresh)) { build() }
    }

    private fun gameCell(row: LinearLayout, i: Int) {
        val pk = p.app(i)
        val label = if (pk.isEmpty()) getString(R.string.add_game)
            else "▶  " + AppCache.label(this, pk)
        row.addView(Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f; maxLines = 2
            typeface = Typeface.DEFAULT_BOLD; setTextColor(if (pk.isEmpty()) Ui.TXT else Ui.BG)
            background = Ui.round(this@MainActivity, if (pk.isEmpty()) Ui.FIELD else Ui.SKY, 12)
            setOnClickListener { if (pk.isEmpty()) pickApp(i) else launchGame(pk) }
            setOnLongClickListener { if (pk.isNotEmpty()) { p.setApp(i, ""); build() }; true }
        }, LinearLayout.LayoutParams(0, 56.dp(), 1f).apply { topMargin = 8.dp(); if (row.childCount > 0) leftMargin = 8.dp() })
    }

    // ---------- แท็บ 2: ปุ่มและมาโคร ----------
    private fun keysTab() {
        val n = p.apps().fold(0) { acc, a -> acc + (try { JSONArray(p.buttons(a)).length() } catch (_: Exception) { 0 }) }
        val bt = card(getString(R.string.onscreen_title), getString(R.string.onscreen_sub, n))
        tv(bt, getString(R.string.onscreen_howto), 13f, Ui.SUB)

        val mc = card(getString(R.string.macro_title), getString(R.string.macro_sub))
        btn(mc, getString(R.string.macro_key, KeyNames.full(this, p.macroKey))) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setMessage(R.string.press_key)
                .setOnKeyListener { d, k, e ->
                    if (e.action == KeyEvent.ACTION_DOWN && k != KeyEvent.KEYCODE_BACK) { p.macroKey = k; d.dismiss(); build(); true } else false
                }.show()
        }
        macroEdit = EditText(this).apply {
            setText(p.macro); minLines = 5; gravity = Gravity.TOP; typeface = Typeface.MONOSPACE
            setTextColor(Ui.TXT); setHintTextColor(Ui.SUB); textSize = 13f
            background = Ui.round(this@MainActivity, Ui.BG, 12); setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
            hint = getString(R.string.macro_hint)
            mc.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8.dp() })
        }
        btn(mc, getString(R.string.macro_save), true) { saveMacro(); toast(R.string.saved) }
    }

    // ---------- แท็บ 3: ตั้งค่า ----------
    private fun settingsTab() {
        val bg = card(getString(R.string.bg_title), getString(R.string.bg_note))
        btn(bg, getString(R.string.bg_pick), true) { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 2) }
        btn(bg, getString(R.string.bg_reset)) { AppBackground.clear(this); toast(R.string.bg_reset_done); build() }
        seek(bg, getString(R.string.bg_dim), "%", 0, 80, p.bgDim) { p.bgDim = it; AppBackground.applyDim(it) }
        bg.addView(CheckBox(this).apply {
            text = getString(R.string.intro_toggle); setTextColor(Ui.TXT); isChecked = p.introOn
            setOnCheckedChangeListener { _, v -> p.introOn = v }
        })

        val sn = card(getString(R.string.sens_title))
        seek(sn, getString(R.string.axis_x), "%", 10, 400, (p.sensX * 100).toInt()) { p.sensX = it / 100f }
        seek(sn, getString(R.string.axis_y), "%", 10, 400, (p.sensY * 100).toInt()) { p.sensY = it / 100f }

        val cu = card(getString(R.string.cursor_title))
        seek(cu, getString(R.string.size), " " + getString(R.string.unit_size), 16, 128, p.cursorDp) { p.cursorDp = it }
        btn(cu, getString(R.string.pick_image)) { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        btn(cu, getString(R.string.default_image)) { File(filesDir, "cursor.png").delete(); toast(R.string.reset_done) }

        val tp = card(getString(R.string.play_title))
        tv(tp, getString(R.string.play_help), 13f, Ui.SUB)
    }

    // ---------- ตัวช่วย ----------
    private fun seek(parent: LinearLayout, label: String, unit: String, min: Int, max: Int, init: Int, set: (Int) -> Unit) {
        val t = tv(parent, "$label: $init$unit", 14f, Ui.TXT)
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val bar = SeekBar(this).apply {
            this.max = max - min; progress = init - min
            progressTintList = ColorStateList.valueOf(Ui.SKY); thumbTintList = ColorStateList.valueOf(Ui.AMBER)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(v + min); t.text = "$label: ${v + min}$unit" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        fun step(sym: String, d: Int) = Button(this).apply {
            text = sym; textSize = 18f; setTextColor(Ui.TXT); minWidth = 0; minimumWidth = 0
            background = Ui.round(this@MainActivity, Ui.FIELD, 10)
            setOnClickListener { bar.progress = (bar.progress + d).coerceIn(0, bar.max) }
        }
        line.addView(step(getString(R.string.adjust_minus), -1), LinearLayout.LayoutParams(44.dp(), 44.dp()))
        line.addView(bar, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(step(getString(R.string.adjust_plus), 1), LinearLayout.LayoutParams(44.dp(), 44.dp()))
        parent.addView(line)
    }

    private fun launchGame(pk: String) {
        if (!serviceOn()) { toast(R.string.toast_enable_acc); return }
        if (!Converter.present(p)) { toast(R.string.toast_no_conv); return }
        val i = packageManager.getLaunchIntentForPackage(pk)
        if (i == null) toast(R.string.toast_cant_launch) else startActivity(i)
    }

    private fun toggleDev(name: String) {
        val cur = Converter.tokens(p).toMutableList()
        val hit = cur.filter { name.contains(it, true) }
        if (hit.isNotEmpty()) cur.removeAll(hit) else cur.add(name)
        p.devs = cur.joinToString(",")
        build()
    }

    private fun pickApp(slot: Int) {
        if (AppCache.launchers.isEmpty()) AppCache.load(this)
        val apps = AppCache.launchers
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setItems(apps.map { it.second }.toTypedArray()) { _, i -> p.setApp(slot, apps[i].first); build() }.show()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        if (rc == 2) {
            if (AppBackground.save(this, u)) { toast(R.string.bg_changed); build() } else toast(R.string.bg_failed)
            return
        }
        if (rc != 1) return
        try {
            val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u))
            FileOutputStream(File(filesDir, "cursor.png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            toast(R.string.image_changed)
        } catch (_: Exception) { toast(R.string.image_failed) }
    }
}
