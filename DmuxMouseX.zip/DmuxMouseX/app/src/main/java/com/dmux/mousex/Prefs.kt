package com.dmux.mousex
import android.content.Context

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("dmux", Context.MODE_PRIVATE)
    var sensX: Float
        get() = sp.getFloat("sx", 1f)
        set(v) { sp.edit().putFloat("sx", v).apply() }
    var sensY: Float
        get() = sp.getFloat("sy", 1f)
        set(v) { sp.edit().putFloat("sy", v).apply() }
    var cursorDp: Int
        get() = sp.getInt("cs", 32)
        set(v) { sp.edit().putInt("cs", v).apply() }
    var macroKey: Int
        get() = sp.getInt("mk", 132)
        set(v) { sp.edit().putInt("mk", v).apply() }
    var macro: String
        get() = sp.getString("macro", "tap 50% 50%\nwait 100")!!
        set(v) { sp.edit().putString("macro", v).apply() }
    var buttons: String
        get() = sp.getString("btns", "[]")!!
        set(v) { sp.edit().putString("btns", v).apply() }
    fun app(i: Int): String = sp.getString("app" + i, "")!!
    fun setApp(i: Int, v: String) { sp.edit().putString("app" + i, v).apply() }
    fun apps(): List<String> = (0..2).map { app(it) }.filter { it.isNotEmpty() }
}
