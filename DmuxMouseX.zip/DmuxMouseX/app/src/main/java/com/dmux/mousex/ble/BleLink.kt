package com.dmux.mousex.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.dmux.mousex.R
import com.dmux.mousex.data.Prefs
import java.util.UUID

/**
 * ตัวจัดการเชื่อมต่อ BLE แบบทั่วไป (เขียนใหม่เอง):
 * สแกน -> เชื่อมต่อ GATT -> ค้นหาบริการ -> สมัครรับ notify -> เขียนข้อมูลเป็นคิว -> ต่อใหม่อัตโนมัติ
 * ไม่ผูกกับโปรโตคอลของยี่ห้อใด ๆ ใส่ UUID ของช่องรับ/ส่งได้เองตอนสร้าง
 */
@SuppressLint("MissingPermission")
class BleLink(private val ctx: Context, private val uuidOut: UUID, private val uuidIn: UUID) {

    enum class State { IDLE, SCANNING, CONNECTING, CONNECTED }

    interface Listener {
        fun onState(s: State, detail: String)
        fun onFound(d: BluetoothDevice, rssi: Int, hid: Boolean)
        fun onData(bytes: ByteArray)
        fun onLog(line: String)
    }

    var listener: Listener? = null
    var state = State.IDLE; private set
    var autoReconnect = true
    private val ui = Handler(Looper.getMainLooper())
    private val HID = UUID.fromString("00001812-0000-1000-8000-00805f9b34fb")
    private val CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val adapter get() = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var gatt: BluetoothGatt? = null
    private var outChar: BluetoothGattCharacteristic? = null
    private var target: BluetoothDevice? = null
    private var userClosed = false
    private var retry = 0
    private val queue = ArrayDeque<ByteArray>()
    private var writing = false
    private val seen = HashSet<String>()

    private fun set(s: State, d: String) { state = s; ui.post { listener?.onState(s, d) } }
    private fun log(s: String) { ui.post { listener?.onLog(s) } }

    fun enabled() = adapter?.isEnabled == true

    // ---------- สแกน ----------
    private val scb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            val d = r.device
            val name = d.name ?: r.scanRecord?.deviceName ?: return
            if (!seen.add(d.address)) return
            val hid = r.scanRecord?.serviceUuids?.any { it.uuid == HID } == true
            ui.post { listener?.onFound(d, r.rssi, hid) }
            log(ctx.getString(R.string.ble_found, name, r.rssi))
        }
        override fun onScanFailed(code: Int) { set(State.IDLE, ctx.getString(R.string.ble_scan_fail, code)) }
    }

    fun scan(seconds: Int = 10) {
        val sc = adapter?.bluetoothLeScanner ?: run { set(State.IDLE, ctx.getString(R.string.ble_no_adapter)); return }
        if (state == State.CONNECTED || state == State.CONNECTING) return
        seen.clear(); set(State.SCANNING, ctx.getString(R.string.ble_scanning, seconds))
        sc.startScan(scb)
        ui.postDelayed({ stopScan(); if (state == State.SCANNING) set(State.IDLE, ctx.getString(R.string.ble_scan_done)) }, seconds * 1000L)
    }

    fun stopScan() { try { adapter?.bluetoothLeScanner?.stopScan(scb) } catch (_: Exception) {} }

    // ---------- เชื่อมต่อ ----------
    fun connect(d: BluetoothDevice) {
        stopScan(); userClosed = false; retry = 0; target = d
        open(d)
    }

    fun connectSaved(address: String): Boolean {
        if (address.isEmpty() || !BluetoothAdapter.checkBluetoothAddress(address)) return false
        val d = adapter?.getRemoteDevice(address) ?: return false
        connect(d); return true
    }

    private fun open(d: BluetoothDevice) {
        gatt?.close(); gatt = null; outChar = null; queue.clear(); writing = false
        set(State.CONNECTING, ctx.getString(R.string.ble_connecting, d.name ?: d.address))
        gatt = if (Build.VERSION.SDK_INT >= 23) d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
               else d.connectGatt(ctx, false, cb)
    }

    fun disconnect() {
        userClosed = true; stopScan()
        gatt?.disconnect(); gatt?.close(); gatt = null; outChar = null
        set(State.IDLE, ctx.getString(R.string.ble_closed))
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, ns: Int) {
            if (ns == BluetoothProfile.STATE_CONNECTED) {
                retry = 0; log(ctx.getString(R.string.ble_discovering)); g.discoverServices()
            } else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                g.close(); if (gatt === g) gatt = null; outChar = null
                set(State.IDLE, ctx.getString(R.string.ble_lost, status))
                val t = target
                if (!userClosed && autoReconnect && t != null && retry < 5) {
                    retry++; val wait = 1500L * retry
                    log(ctx.getString(R.string.ble_retry, retry, (wait / 1000.0).toString()))
                    ui.postDelayed({ if (!userClosed && gatt == null) open(t) }, wait)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val all = g.services.flatMap { it.characteristics }
            for (s in g.services) log(ctx.getString(R.string.ble_service, s.uuid.toString().substring(0, 8)))
            outChar = all.firstOrNull { it.uuid == uuidOut }
            val inp = all.firstOrNull { it.uuid == uuidIn }
            if (inp == null) { set(State.CONNECTED, ctx.getString(R.string.ble_no_in)); return }
            g.setCharacteristicNotification(inp, true)
            val ds = inp.getDescriptor(CCC)
            if (ds != null) { ds.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(ds) }
            set(State.CONNECTED, ctx.getString(R.string.ble_ready))
            target?.let { Prefs(ctx).apply { lastDevAddr = it.address; lastDevName = it.name ?: it.address } }
        }

        @Deprecated("old signature")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            ui.post { listener?.onData(v) }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writing = false; pumpWrites()
        }
    }

    // ---------- เขียนข้อมูล (เข้าคิว ทีละชุด) ----------
    fun send(b: ByteArray): Boolean {
        if (outChar == null || state != State.CONNECTED) return false
        queue.addLast(b); pumpWrites(); return true
    }

    private fun pumpWrites() {
        if (writing) return
        val g = gatt ?: return; val c = outChar ?: return
        val b = queue.removeFirstOrNull() ?: return
        writing = true
        c.value = b
        if (!g.writeCharacteristic(c)) { writing = false; log(ctx.getString(R.string.ble_write_fail)) }
    }

    fun close() { userClosed = true; stopScan(); gatt?.close(); gatt = null; ui.removeCallbacksAndMessages(null) }
}
