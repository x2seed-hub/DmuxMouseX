package com.dmux.mousex.data

import android.content.Context
import android.view.KeyEvent
import com.dmux.mousex.R

/** ชื่อปุ่มคีย์บอร์ดเป็นภาษาไทย: แบบสั้นสำหรับปุ่มวงกลมบนจอ และแบบเต็มสำหรับข้อความ */
object KeyNames {
    private fun base(k: Int) = KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")

    private val shortIds = mapOf(
        "SPACE" to R.string.ks_space, "SHIFT_LEFT" to R.string.ks_shift, "SHIFT_RIGHT" to R.string.ks_shift,
        "CTRL_LEFT" to R.string.ks_ctrl, "CTRL_RIGHT" to R.string.ks_ctrl,
        "ALT_LEFT" to R.string.ks_alt, "ALT_RIGHT" to R.string.ks_alt,
        "TAB" to R.string.ks_tab, "ENTER" to R.string.ks_enter, "ESCAPE" to R.string.ks_esc,
        "DEL" to R.string.ks_del, "CAPS_LOCK" to R.string.ks_caps
    )
    private val fullIds = mapOf(
        "SPACE" to R.string.kf_space, "SHIFT_LEFT" to R.string.kf_shift_l, "SHIFT_RIGHT" to R.string.kf_shift_r,
        "CTRL_LEFT" to R.string.kf_ctrl_l, "CTRL_RIGHT" to R.string.kf_ctrl_r,
        "ALT_LEFT" to R.string.kf_alt_l, "ALT_RIGHT" to R.string.kf_alt_r,
        "TAB" to R.string.kf_tab, "ENTER" to R.string.kf_enter, "ESCAPE" to R.string.kf_esc,
        "DEL" to R.string.kf_del, "CAPS_LOCK" to R.string.kf_caps,
        "DPAD_UP" to R.string.kf_up, "DPAD_DOWN" to R.string.kf_down,
        "DPAD_LEFT" to R.string.kf_left, "DPAD_RIGHT" to R.string.kf_right
    )

    fun short(c: Context, k: Int): String {
        if (k == 0) return "?"
        val n = base(k)
        when (n) { "DPAD_UP" -> return "↑"; "DPAD_DOWN" -> return "↓"; "DPAD_LEFT" -> return "←"; "DPAD_RIGHT" -> return "→" }
        shortIds[n]?.let { return c.getString(it) }
        return if (n.length > 3) n.take(3) else n
    }

    fun full(c: Context, k: Int): String {
        if (k == 0) return "?"
        val n = base(k)
        return fullIds[n]?.let { c.getString(it) } ?: n
    }
}
