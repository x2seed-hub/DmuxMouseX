package com.dmux.mousex

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Btn(var key: Int, var x: Float, var y: Float, var dp: Int)
class Ptr(var px: Float, var py: Float) {
    var tx = px; var ty = py; var up = false
    var stroke: GestureDescription.StrokeDescription? = null
}

class MouseService : AccessibilityService() {
    private lateinit var p: Prefs
    private lateinit var wm: WindowManager
    private var ov: Overlay? = null
    private var tab: TextView? = null
    private var editor: FrameLayout? = null
    private var hint: TextView? = null
    private var sel: Btn? = null
    private var binding = false
    private var capture = true
    private var aim = false
    private var dragging = false
    private var reanchor = false
    private var busy = false
    private var cx = 0f; private var cy = 0f
    private var lastButtons = 0
    private val btns = ArrayList<Btn>()
    private val ptrs = LinkedHashMap<Int, Ptr>()   // -1 = mouse, 0.. = on-screen buttons
    private val pressed = HashSet<Int>()
    @Volatile private var macroRunning = false
    private val dm get() = resources.displayMetrics
    private val W get() = dm.widthPixels
    private val H get() = dm.heightPixels
    private val ax get() = W * 0.75f
    private val ay get() = H * 0.5f
    private fun dp(v: Int) = (v * dm.density).toInt()
    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.WHITE; isFakeBoldText = true }

    private fun label(k: Int): String {
        if (k == 0) return "?"
        val n = KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")
        return when (n) {
            "SPACE" -> "Spc"; "SHIFT_LEFT", "SHIFT_RIGHT" -> "Sh"; "CTRL_LEFT", "CTRL_RIGHT" -> "Ct"
            "ALT_LEFT", "ALT_RIGHT" -> "Alt"; "TAB" -> "Tab"; "ENTER" -> "Ent"; "ESCAPE" -> "Esc"
            "DPAD_UP" -> "↑"; "DPAD_DOWN" -> "↓"; "DPAD_LEFT" -> "←"; "DPAD_RIGHT" -> "→"
            else -> if (n.length > 3) n.take(3) else n
        }
    }

    private fun paintBtn(c: Canvas, x: Float, y: Float, r: Float, t: String, on: Boolean, sel: Boolean) {
        fp.color = if (on) 0xAA7C6CF0.toInt() else 0x66000000
        c.drawCircle(x, y, r, fp)
        spaint.color = if (sel) 0xFFFFD166.toInt() else 0xCCFFFFFF.toInt()
        spaint.strokeWidth = if (sel) 6f else 3f
        c.drawCircle(x, y, r - 3f, spaint)
        tp.textSize = r * (if (t.length >= 3) 0.62f else 0.9f)
        c.drawText(t, x, y - (tp.descent() + tp.ascent()) / 2, tp)
    }

    inner class Overlay : View(this@MouseService) {
        var bmp: Bitmap? = null
        init {
            isFocusable = true; isFocusableInTouchMode = true
            setOnCapturedPointerListener { _, e -> onPointer(e); true }
        }
        override fun onDraw(c: Canvas) {
            if (editor != null) return
            for ((i, b) in btns.withIndex()) paintBtn(c, b.x * W, b.y * H, dp(b.dp) / 2f, label(b.key), pressed.contains(i), false)
            if (aim || !capture) return
            bmp?.let { c.drawBitmap(it, cx, cy, null) }
        }
        override fun onWindowFocusChanged(has: Boolean) {
            super.onWindowFocusChanged(has)
            if (has && capture) requestPointerCapture()
        }
    }

    inner class BView(val b: Btn) : View(this@MouseService) {
        override fun onDraw(c: Canvas) { val r = width / 2f; paintBtn(c, r, r, r, label(b.key), false, sel === b) }
    }

    override fun onServiceConnected() {
        p = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pk = e.packageName?.toString() ?: return
        if (pk == packageName) return
        if (p.apps().contains(pk)) show() else hide()
    }

    override fun onInterrupt() {}
    override fun onDestroy() { hide(); super.onDestroy() }

    private fun lp(focusable: Boolean) = WindowManager.LayoutParams(
        -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE),
        PixelFormat.TRANSLUCENT)

    private fun show() {
        if (ov != null) return
        loadBtns()
        val o = Overlay(); o.bmp = loadCursor(); ov = o
        capture = true; aim = false; cx = W / 2f; cy = H / 2f
        wm.addView(o, lp(true))
        makeTab()
    }

    private fun hide() {
        val o = ov ?: return
        ov = null; aim = false; dragging = false; reanchor = false
        ptrs.values.forEach { it.up = true }; pump(); pressed.clear()
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }; editor = null
        tab?.let { try { wm.removeView(it) } catch (_: Exception) {} }; tab = null
        try { o.releasePointerCapture(); wm.removeView(o) } catch (_: Exception) {}
    }

    private fun setCapture(on: Boolean) {
        val o = ov ?: return
        capture = on
        if (on) { wm.updateViewLayout(o, lp(true)); o.requestFocus(); o.requestPointerCapture() }
        else { o.releasePointerCapture(); wm.updateViewLayout(o, lp(false)) }
        o.invalidate()
    }

    private fun loadCursor(): Bitmap {
        val s = dp(p.cursorDp)
        val f = File(filesDir, "cursor.png")
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return Bitmap.createScaledBitmap(it, s, s, true) }
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b); val pa = Paint(Paint.ANTI_ALIAS_FLAG); val f1 = s.toFloat()
        val path = Path().apply {
            moveTo(0f, 0f); lineTo(0f, f1 * .85f); lineTo(f1 * .25f, f1 * .65f)
            lineTo(f1 * .45f, f1 * .95f); lineTo(f1 * .58f, f1 * .88f)
            lineTo(f1 * .4f, f1 * .6f); lineTo(f1 * .7f, f1 * .6f); close()
        }
        pa.color = Color.WHITE; c.drawPath(path, pa)
        pa.style = Paint.Style.STROKE; pa.strokeWidth = 3f; pa.color = Color.BLACK; c.drawPath(path, pa)
        return b
    }

    // ---------- saved buttons ----------
    private fun loadBtns() {
        btns.clear()
        try {
            val a = JSONArray(p.buttons)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                btns.add(Btn(o.getInt("k"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getInt("s")))
            }
        } catch (_: Exception) {}
    }

    private fun saveBtns() {
        val a = JSONArray()
        for (b in btns) a.put(JSONObject().put("k", b.key).put("x", b.x.toDouble()).put("y", b.y.toDouble()).put("s", b.dp))
        p.buttons = a.toString()
    }

    // ---------- floating edit tab + editor ----------
    private fun makeTab() {
        val l = WindowManager.LayoutParams(dp(44), dp(44), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START; l.x = dp(8); l.y = (H * 0.35f).toInt()
        val t = TextView(this).apply {
            text = "✎"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x997C6CF0.toInt()) }
        }
        t.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = l.x; oy = l.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        if (Math.abs(e.rawX - sx) + Math.abs(e.rawY - sy) > 12) moved = true
                        if (moved) { l.x = ox + (e.rawX - sx).toInt(); l.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, l) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) enterEdit()
                }
                return true
            }
        })
        tab = t; wm.addView(t, l)
    }

    private fun enterEdit() {
        if (editor != null || ov == null) return
        setCapture(false); tab?.visibility = View.GONE
        val f = FrameLayout(this); f.setBackgroundColor(0x66000000)
        editor = f; sel = null; binding = false
        for (b in btns) mkView(b)
        f.addView(bar(), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(8) })
        wm.addView(f, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT))
        ov?.invalidate()
    }

    private fun exitEdit() {
        btns.removeAll { it.key == 0 }; saveBtns()
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        editor = null; sel = null; binding = false
        tab?.visibility = View.VISIBLE; setCapture(true)
    }

    private fun bar(): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10), dp(8), dp(10), dp(8)); background = rr(0xEE171A21.toInt(), 16)
        }
        val row = LinearLayout(this)
        fun b(t: String, bg: Int, f: () -> Unit) {
            val x = Button(this).apply {
                text = t; isAllCaps = false; setTextColor(Color.WHITE); background = rr(bg, 10)
                minWidth = 0; minimumWidth = 0; setPadding(dp(14), 0, dp(14), 0); setOnClickListener { f() }
            }
            row.addView(x, LinearLayout.LayoutParams(-2, dp(40)).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        b("+ เพิ่มปุ่ม", 0xFF7C6CF0.toInt()) { addBtn() }
        b("ลบ", 0xFF3A3F4B.toInt()) { delBtn() }
        b("ใหญ่", 0xFF3A3F4B.toInt()) { resize(8) }
        b("เล็ก", 0xFF3A3F4B.toInt()) { resize(-8) }
        b("เสร็จ", 0xFF22A06B.toInt()) { exitEdit() }
        hint = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(0, dp(6), 0, 0) }
        col.addView(row); col.addView(hint); updateHint(); return col
    }

    private fun updateHint() {
        hint?.text = when {
            binding -> "กดปุ่มบนคีย์บอร์ดที่ต้องการให้เป็นปุ่มนี้"
            sel != null -> "ลากเพื่อย้าย • แตะซ้ำเพื่อเปลี่ยนปุ่มคีย์บอร์ด"
            else -> "กด + เพิ่มปุ่ม หรือแตะปุ่มที่มีอยู่เพื่อแก้ไข"
        }
    }

    private fun viewOf(b: Btn): BView? {
        val f = editor ?: return null
        for (i in 0 until f.childCount) { val c = f.getChildAt(i); if (c is BView && c.b === b) return c }
        return null
    }

    private fun place(v: BView) {
        val s = dp(v.b.dp)
        v.layoutParams = FrameLayout.LayoutParams(s, s)
        v.x = v.b.x * W - s / 2f; v.y = v.b.y * H - s / 2f
    }

    private fun select(b: Btn?) {
        sel = b; binding = b != null && b.key == 0
        editor?.let { f -> for (i in 0 until f.childCount) f.getChildAt(i).invalidate() }
        updateHint()
    }

    private fun addBtn() {
        val b = Btn(0, 0.5f, 0.5f, 56); btns.add(b); mkView(b); select(b)
    }

    private fun delBtn() {
        val s = sel ?: return
        btns.remove(s); viewOf(s)?.let { editor?.removeView(it) }; select(null)
    }

    private fun resize(d: Int) {
        val s = sel ?: return
        s.dp = (s.dp + d).coerceIn(32, 120); viewOf(s)?.let { place(it) }
    }

    private fun mkView(b: Btn) {
        val v = BView(b); place(v)
        v.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var moved = false; var was = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { was = sel === b; select(b); dx = e.rawX - v.x; dy = e.rawY - v.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val nx = e.rawX - dx; val ny = e.rawY - dy
                        if (Math.abs(nx - v.x) + Math.abs(ny - v.y) > 10) moved = true
                        if (moved) { v.x = nx; v.y = ny }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            b.x = ((v.x + v.width / 2f) / W).coerceIn(0f, 1f)
                            b.y = ((v.y + v.height / 2f) / H).coerceIn(0f, 1f)
                        } else if (was) { binding = true; updateHint() }
                    }
                }
                return true
            }
        })
        editor!!.addView(v)
    }

    // ---------- mouse input ----------
    private fun onPointer(e: MotionEvent) {
        if (e.actionMasked == MotionEvent.ACTION_MOVE) move(e.x * p.sensX, e.y * p.sensY)
        val b = e.buttonState; val ch = b xor lastButtons; lastButtons = b
        if ((ch and MotionEvent.BUTTON_PRIMARY) != 0) {
            if ((b and MotionEvent.BUTTON_PRIMARY) != 0) down() else up()
        }
        if ((ch and MotionEvent.BUTTON_SECONDARY) != 0 && (b and MotionEvent.BUTTON_SECONDARY) != 0)
            performGlobalAction(GLOBAL_ACTION_BACK)
        if ((ch and MotionEvent.BUTTON_TERTIARY) != 0 && (b and MotionEvent.BUTTON_TERTIARY) != 0) toggleAim()
    }

    private fun move(dx: Float, dy: Float) {
        if (aim) {
            val q = ptrs[-1] ?: return
            if (reanchor) return
            q.tx = (q.tx + dx).coerceIn(0f, W - 1f); q.ty = (q.ty + dy).coerceIn(0f, H - 1f)
            if (Math.abs(q.tx - ax) > W * .3f || Math.abs(q.ty - ay) > H * .3f) { q.up = true; reanchor = true }
            pump(); return
        }
        cx = (cx + dx).coerceIn(0f, W - 1f); cy = (cy + dy).coerceIn(0f, H - 1f)
        ov?.invalidate()
        if (dragging) ptrs[-1]?.let { it.tx = cx; it.ty = cy; pump() }
    }

    private fun down() { if (aim) return; dragging = true; ptrs[-1] = Ptr(cx, cy); pump() }
    private fun up() { dragging = false; if (!aim) { ptrs[-1]?.up = true; pump() } }

    private fun toggleAim() {
        aim = !aim
        if (aim) { ptrs[-1] = Ptr(ax, ay) } else { reanchor = false; ptrs[-1]?.up = true }
        pump(); ov?.invalidate()
    }

    // ---------- multi-touch engine: all fingers in one gesture ----------
    private fun needs() = ptrs.values.any { it.up || it.stroke == null || it.tx != it.px || it.ty != it.py }

    private fun pump() {
        if (busy || ptrs.isEmpty() || !needs()) return
        val g = GestureDescription.Builder(); val ending = ArrayList<Int>()
        for ((id, q) in ptrs) {
            val path = Path().apply { moveTo(q.px, q.py); if (q.tx != q.px || q.ty != q.py) lineTo(q.tx, q.ty) }
            val s = q.stroke
            val ns = if (s == null) GestureDescription.StrokeDescription(path, 0, 16, !q.up)
                     else s.continueStroke(path, 0, 16, !q.up)
            q.px = q.tx; q.py = q.ty; q.stroke = ns
            if (q.up) ending.add(id)
            g.addStroke(ns)
        }
        busy = true
        val ok = dispatchGesture(g.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                busy = false
                for (id in ending) ptrs.remove(id)
                if (reanchor && !ptrs.containsKey(-1)) { reanchor = false; if (aim) ptrs[-1] = Ptr(ax, ay) }
                pump()
            }
            override fun onCancelled(d: GestureDescription?) { busy = false; ptrs.clear(); reanchor = false }
        }, null)
        if (!ok) { busy = false; ptrs.clear() }
    }

    // ---------- keyboard ----------
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (ov == null) return false
        val k = e.keyCode; val down = e.action == KeyEvent.ACTION_DOWN
        if (editor != null) {
            val s = sel
            if (down && binding && s != null && k != KeyEvent.KEYCODE_F1) {
                s.key = k; binding = false; select(s); return true
            }
            return false
        }
        if (k == KeyEvent.KEYCODE_F1) { if (down) setCapture(!capture); return true }
        if (!capture) return false
        if (k == p.macroKey) { if (down) runMacro(); return true }
        for ((i, b) in btns.withIndex()) {
            if (b.key != k) continue
            if (down) {
                if (e.repeatCount == 0 && !ptrs.containsKey(i)) { pressed.add(i); ptrs[i] = Ptr(b.x * W, b.y * H); ov?.invalidate(); pump() }
            } else { pressed.remove(i); ptrs[i]?.up = true; ov?.invalidate(); pump() }
            return true
        }
        return false
    }

    // ---------- macro ----------
    private fun coord(s: String, max: Int) =
        if (s.endsWith("%")) s.dropLast(1).toFloat() / 100f * max else s.toFloat()

    private fun gesture(path: Path, ms: Long) {
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build(), null, null)
    }

    private fun runMacro() {
        if (macroRunning) return
        macroRunning = true
        val lines = p.macro.lines()
        Thread {
            try {
                for (l in lines) {
                    val t = l.trim().split(" ").filter { it.isNotEmpty() }
                    if (t.isEmpty()) continue
                    try {
                        when (t[0]) {
                            "tap" -> { gesture(Path().apply { moveTo(coord(t[1], W), coord(t[2], H)) }, 50); Thread.sleep(90) }
                            "wait" -> Thread.sleep(t[1].toLong())
                            "swipe" -> {
                                val ms = t[5].toLong()
                                gesture(Path().apply { moveTo(coord(t[1], W), coord(t[2], H)); lineTo(coord(t[3], W), coord(t[4], H)) }, ms)
                                Thread.sleep(ms + 50)
                            }
                        }
                    } catch (_: Exception) {}
                }
            } finally { macroRunning = false }
        }.start()
    }
}
