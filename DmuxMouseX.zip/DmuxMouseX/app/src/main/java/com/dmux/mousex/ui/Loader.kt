package com.dmux.mousex.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.dmux.mousex.R
import com.dmux.mousex.data.AppCache
import com.dmux.mousex.data.Converter
import com.dmux.mousex.data.Prefs
import java.io.File

/**
 * โหลดข้อมูลจริงตอนเปิดแอป แล้วรายงานความคืบหน้าตามงานที่ทำเสร็จจริง
 * (ไม่มีการหน่วงเวลาหรือเดาตัวเลข): เปอร์เซ็นต์ = น้ำหนักงานที่เสร็จ / น้ำหนักงานทั้งหมด
 */
class Loader(private val ctx: Context, private val report: (Float, String) -> Unit) {
    private class Task(val label: Int, val weight: Float, val run: ((Float) -> Unit) -> Unit)

    private val ui = Handler(Looper.getMainLooper())

    fun start() {
        val app = ctx.applicationContext
        val tasks = listOf(
            Task(R.string.ld_settings, 1f) { _ -> Prefs(app).let { it.sensX; it.sensY; it.macro; it.apps() } },
            Task(R.string.ld_background, 3f) { _ -> AppBackground.load(app) },
            Task(R.string.ld_cursor, 1f) { _ ->
                val f = File(app.filesDir, "cursor.png")
                if (f.exists()) BitmapFactory.decodeFile(f.path)
            },
            Task(R.string.ld_apps, 4f) { rep -> AppCache.load(app, rep) },
            Task(R.string.ld_device, 1f) { _ -> Converter.present(Prefs(app)) },
            Task(R.string.ld_service, 1f) { _ ->
                Settings.Secure.getString(app.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            }
        )
        val total = tasks.sumOf { it.weight.toDouble() }.toFloat()
        Thread {
            var done = 0f
            for (t in tasks) {
                val name = app.getString(t.label)
                post(done / total, name)
                try { t.run { f -> post((done + t.weight * f) / total, name) } } catch (_: Throwable) {}
                done += t.weight
            }
            post(1f, app.getString(R.string.ld_ready))
        }.start()
    }

    private fun post(f: Float, label: String) { ui.post { report(f.coerceIn(0f, 1f), label) } }
}
