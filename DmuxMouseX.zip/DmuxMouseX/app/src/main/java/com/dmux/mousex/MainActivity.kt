package com.dmux.mousex

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.widget.*
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val BG = 0xFF0E1014.toInt()
    private val CARD = 0xFF171A21.toInt()
    private val FIELD = 0xFF262A33.toInt()
    private val ACCENT = 0xFF7C6CF0.toInt()
    private val TXT = 0xFFECEEF3.toInt()
    private val SUB = 0xFF8A90A0.toInt()
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private var macroEdit: EditText? = null

    override fun onCreate(b: Bundle?) { super.onCreate(b); p = Prefs(this) }
    override fun onResume() { super.onResume(); build() }
    override fun onPause() { macroEdit?.let { p.macro = it.text.toString() }; super.onPause() }

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    private fun rr(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r.dp().toFloat() }

    private fun tv(parent: LinearLayout, t: String, size: Float = 14f, color: Int = SUB, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color); setPadding(0, 4.dp(), 0, 4.dp())
            if (bold) typeface = Typeface.DEFAULT_BOLD
            parent.addView(this)
        }

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rr(CARD, 18)
            setPadding(18.dp(), 14.dp(), 18.dp(), 16.dp())
        }
        box.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12.dp() })
        tv(c, title, 17f, TXT, true)
        sub?.let { tv(c, it, 13f, SUB) }
        return c
    }

    private fun btn(parent: LinearLayout, t: String, primary: Boolean = false, click: () -> Unit) =
        Button(this).apply {
            text = t; isAllCaps = false; setTextColor(TXT); textSize = 14f
            background = rr(if (primary) ACCENT else FIELD, 12)
            setOnClickListener { click() }
            parent.addView(this, LinearLayout.LayoutParams(-1, 48.dp()).apply { topMargin = 8.dp() })
        }

    private fun seek(parent: LinearLayout, label: String, unit: String, min: Int, max: Int, init: Int, set: (Int) -> Unit) {
        val t = tv(parent, label + ": " + init + unit, 14f, TXT)
        parent.addView(SeekBar(this).apply {
            this.max = max - min; progress = init - min
            progressTintList = ColorStateList.valueOf(ACCENT); thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(v + min); t.text = label + ": " + (v + min) + unit }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun serviceOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(packageName) == true

    private fun build() {
        window.statusBarColor = BG; window.navigationBarColor = BG
        val sv = ScrollView(this).apply { setBackgroundColor(BG) }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 40.dp(), 16.dp(), 32.dp()) }
        sv.addView(box); setContentView(sv)

        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4.dp(), 0, 4.dp(), 16.dp()) }
        tv(head, "Dmux Mouse X", 30f, TXT, true); tv(head, "ใช้เมาส์และคีย์บอร์ดเล่นเกมมือถือ", 14f, SUB)
        box.addView(head)

        val on = serviceOn()
        val st = card("สถานะ")
        tv(st, if (on) "● พร้อมใช้งาน" else "● ยังไม่ได้เปิดบริการ", 14f, if (on) 0xFF4ADE80.toInt() else 0xFFFBBF24.toInt())
        btn(st, if (on) "ตั้งค่า Accessibility" else "เปิดบริการ Accessibility", !on) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val ap = card("แอปเกม", "เลือกได้สูงสุด 3 แอป • กดค้างที่ช่องเพื่อลบ")
        for (i in 0..2) {
            val pk = p.app(i)
            val name = if (pk.isEmpty()) "+ เพิ่มแอป" else try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pk, 0)).toString()
            } catch (_: Exception) { pk }
            btn(ap, name, false) { pickApp(i) }.setOnLongClickListener { p.setApp(i, ""); build(); true }
        }

        val n = try { JSONArray(p.buttons).length() } catch (_: Exception) { 0 }
        val bt = card("ปุ่มบนหน้าจอ", "ตอนนี้มี " + n + " ปุ่ม")
        tv(bt, "1) เปิดเกมที่เลือกไว้\n2) แตะไอคอน ✎ ที่ลอยอยู่\n3) กด “+ เพิ่มปุ่ม” จะได้ปุ่มเปล่า\n" +
            "4) กดปุ่มบนคีย์บอร์ดที่ต้องการ\n5) ลากปุ่มไปวางตรงจุด แล้วกด “เสร็จ”\n\nจอยสติ๊ก: กด “+ จอย” แล้วกดปุ่ม ขึ้น/ซ้าย/ลง/ขวา ตามลำดับ (เช่น W A S D)", 13f, SUB)

        val cv = card("ตัวแปลงบลูทูธ (ทดสอบ)", "สแกน เชื่อมต่อ และดูข้อมูลที่ตัวแปลงส่งมา แบบอ่านอย่างเดียว")
        btn(cv, "เปิดหน้าทดสอบตัวแปลง", false) { startActivity(Intent(this, ConverterActivity::class.java)) }

        val sn = card("ความไวเมาส์")
        seek(sn, "แกน X", "%", 10, 400, (p.sensX * 100).toInt()) { p.sensX = it / 100f }
        seek(sn, "แกน Y", "%", 10, 400, (p.sensY * 100).toInt()) { p.sensY = it / 100f }

        val cu = card("รูปเมาส์")
        seek(cu, "ขนาด", "dp", 16, 128, p.cursorDp) { p.cursorDp = it }
        btn(cu, "เลือกรูป (PNG)") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        btn(cu, "ใช้รูปเริ่มต้น") { File(filesDir, "cursor.png").delete(); Toast.makeText(this, "รีเซ็ตแล้ว", Toast.LENGTH_SHORT).show() }

        val mc = card("มาโคร", "tap x y • wait ms • swipe x1 y1 x2 y2 ms (ใส่ % ได้)")
        btn(mc, "ปุ่มมาโคร: " + KeyEvent.keyCodeToString(p.macroKey).removePrefix("KEYCODE_") + "  (แตะเพื่อเปลี่ยน)") {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setMessage("กดปุ่มบนคีย์บอร์ดที่ต้องการ")
                .setOnKeyListener { d, k, e ->
                    if (e.action == KeyEvent.ACTION_DOWN && k != KeyEvent.KEYCODE_BACK) { p.macroKey = k; d.dismiss(); build(); true } else false
                }.show()
        }
        macroEdit = EditText(this).apply {
            setText(p.macro); minLines = 5; gravity = Gravity.TOP; typeface = Typeface.MONOSPACE
            setTextColor(TXT); setHintTextColor(SUB); textSize = 13f
            background = rr(BG, 12); setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
            hint = "tap 50% 50%\nwait 100"
            mc.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8.dp() })
        }
        btn(mc, "บันทึกมาโคร", true) { p.macro = macroEdit!!.text.toString(); Toast.makeText(this, "บันทึกแล้ว", Toast.LENGTH_SHORT).show() }

        val tp = card("ปุ่มเมาส์ตอนเล่น")
        tv(tp, "คลิกซ้าย = แตะ/ลาก\nคลิกขวา = ย้อนกลับ\nคลิกกลาง = โหมดเล็ง/หมุนกล้อง\nF1 = ปล่อย/จับเมาส์", 13f, SUB)
    }

    private fun pickApp(slot: Int) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.sortedBy { it.second }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setItems(apps.map { it.second }.toTypedArray()) { _, i -> p.setApp(slot, apps[i].first); build() }.show()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc != 1 || res != RESULT_OK) return
        try {
            val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(u))
            FileOutputStream(File(filesDir, "cursor.png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "เปลี่ยนรูปแล้ว", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "อ่านรูปไม่ได้", Toast.LENGTH_SHORT).show() }
    }
}
